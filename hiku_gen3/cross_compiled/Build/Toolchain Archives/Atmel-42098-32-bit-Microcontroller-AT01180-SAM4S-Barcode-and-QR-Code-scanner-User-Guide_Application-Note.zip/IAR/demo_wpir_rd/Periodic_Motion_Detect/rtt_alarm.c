/* ----------------------------------------------------------------------------
 *         ATMEL Microcontroller Software Support
 * ----------------------------------------------------------------------------
 * Copyright (c) 2009, Atmel Corporation
 *
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * - Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the disclaimer below.
 *
 * Atmel's name may not be used to endorse or promote products derived from
 * this software without specific prior written permission.
 *
 * DISCLAIMER: THIS SOFTWARE IS PROVIDED BY ATMEL "AS IS" AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT ARE
 * DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA,
 * OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ----------------------------------------------------------------------------
 */

/*----------------------------------------------------------------------------
 *        Headers
 *----------------------------------------------------------------------------*/
#include <stdbool.h>

#include "board.h"
#include "rtt_alarm.h"

/*----------------------------------------------------------------------------
 *        Local variables
 *----------------------------------------------------------------------------*/

/* timeout flag*/
static bool bIsAlarmed = false;

/*----------------------------------------------------------------------------
 *        Exported functions
 *----------------------------------------------------------------------------*/

/** RTT interrupt handler*/
void RTT_IrqHandler(void)
{
    uint32_t status = RTT_GetStatus(RTT);
    
    if( status & RTT_SR_ALMS)
    {
        bIsAlarmed = true;
        RTT->RTT_MR &= (uint32_t)(~RTT_MR_ALMIEN);
    }
}
/**
 * dwMs ms delay set up
 */
void RTT_SetMsAlarm(uint32_t dwMs)
{
    uint32_t value;
   

    /* clock from divider is 32768/16 = 2048Hz*/
    RTT->RTT_MR = 0x10;
    /* set alarm value*/
    value = (dwMs * 2048) / 1000;
    
    RTT_SetAlarm(RTT,value);
     
}

/** restart RTT*/
void RTT_Restart(void)
{
    RTT->RTT_MR |= RTT_MR_RTTRST;
    /* wait for restart finished,resyncronization*/
    while(RTT->RTT_VR != 0);
}

/** clear RTT status*/
void RTT_ClearAlarm(void)
{
    RTT->RTT_SR;  
}

/** intialize dwMs ms alarm*/
void RTT_AlarmTimeout_Init(uint32_t dwMs)
{
    RTT_ClearAlarm();
    RTT_SetMsAlarm(dwMs);
    RTT_Restart();

}

/** Enable rtt alarm interrupt*/
void RTT_AlarmTimeout_Enabled(void)
{
    RTT_EnableIT(RTT,RTT_MR_ALMIEN);
    NVIC_EnableIRQ((IRQn_Type)ID_RTT);
}

/** Disable RTT alarm interrupt*/
void RTT_AlarmTimeout_Disabled(void)
{
     NVIC_DisableIRQ((IRQn_Type)ID_RTT);
     RTT->RTT_MR &= (uint32_t)(~RTT_MR_ALMIEN);
}

/** return the status of alarm*/
bool RTT_IsAlarmed(void)
{
    return bIsAlarmed;
}

/** reset RTT alarm flag*/
void RTT_ResetAlarm(void)
{
    bIsAlarmed = false;
}
