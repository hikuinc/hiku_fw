/* ----------------------------------------------------------------------------
 *         ATMEL Microcontroller Software Support
 * ----------------------------------------------------------------------------
 * Copyright (c) 2012, Atmel Corporation
 *
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * - Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the disclaimer below.
 *
 * Atmel's name may not be used to endorse or promote products derived from
 * this software without specific prior written permission.
 *
 * DISCLAIMER: THIS SOFTWARE IS PROVIDED BY ATMEL "AS IS" AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT ARE
 * DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA,
 * OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ----------------------------------------------------------------------------
 */

/**
 * \file
 *
 * Provides the low-level initialization function that called on chip startup.
 */

/*----------------------------------------------------------------------------
 *        Headers
 *----------------------------------------------------------------------------*/
#include "board.h"
#include "board_low_level_backup.h"

/*----------------------------------------------------------------------------
 *        Local definitions
 *----------------------------------------------------------------------------*/

/* Clock settings at 48MHz */
#if (BOARD_MCK == 48000000)
#define	NUMBER_WS	2
#define BOARD_OSCOUNT   (CKGR_MOR_MOSCXTST(0x8))
#define BOARD_PLLBR     (CKGR_PLLBR_MULB(3) \
                       | CKGR_PLLBR_PLLBCOUNT(0x1) \
                       | CKGR_PLLBR_DIVB(1))
#define BOARD_PLLAR     (CKGR_PLLAR_STUCKTO1 | CKGR_PLLAR_MULA(7) \
                       | CKGR_PLLAR_PLLACOUNT(0x1) \
                       | CKGR_PLLAR_DIVA(1))
#define BOARD_MCKR      (PMC_MCKR_PRES_CLK | PMC_MCKR_CSS_PLLB_CLK)
/* Clock settings at 64MHz */
#elif (BOARD_MCK == 64000000)
#define	NUMBER_WS	3
#define BOARD_OSCOUNT   (CKGR_MOR_MOSCXTST(0x8))
#define BOARD_PLLBR     (CKGR_PLLBR_MULB(31) \
                       | CKGR_PLLBR_PLLBCOUNT(0x1) \
                       | CKGR_PLLBR_DIVB(3))
#define BOARD_PLLAR     (CKGR_PLLAR_STUCKTO1 | CKGR_PLLAR_MULA(7) \
                       | CKGR_PLLAR_PLLACOUNT(0x1) \
                       | CKGR_PLLAR_DIVA(1))
#define BOARD_MCKR      (PMC_MCKR_PRES_CLK_2 | PMC_MCKR_CSS_PLLB_CLK)
/* Clock settings at 120MHz */
#elif (BOARD_MCK == 120000000)
#define	NUMBER_WS	5
#define BOARD_OSCOUNT   (CKGR_MOR_MOSCXTST(0x8))
#define BOARD_PLLBR     (CKGR_PLLBR_MULB(29) \
                       | CKGR_PLLBR_PLLBCOUNT(0x1) \
                       | CKGR_PLLBR_DIVB(3))
#define BOARD_PLLAR     (CKGR_PLLAR_STUCKTO1 | CKGR_PLLAR_MULA(7) \
                       | CKGR_PLLAR_PLLACOUNT(0x1) \
                       | CKGR_PLLAR_DIVA(1))
#define BOARD_MCKR      (PMC_MCKR_PRES_CLK | PMC_MCKR_CSS_PLLB_CLK)
#else
    #error "No settings for current BOARD_MCK."
#endif

/* Define clock timeout */
#define CLOCK_TIMEOUT    0xFFFFFFFF

/*----------------------------------------------------------------------------
 *        Local functions
 *----------------------------------------------------------------------------*/
static void _Enable_PMC_Int(void)
{
    PMC->PMC_IER = PMC_IER_LOCKB;
    NVIC_DisableIRQ(PMC_IRQn);
    NVIC_ClearPendingIRQ(PMC_IRQn);
    NVIC_SetPriority(PMC_IRQn, 0);
    NVIC_EnableIRQ(PMC_IRQn);
}

/*----------------------------------------------------------------------------
 *        Exported functions
 *----------------------------------------------------------------------------*/
/** PMC irq handler*/
void PMC_IrqHandler()
{
    PMC->PMC_IDR = PMC_IDR_LOCKB;
}
/**
 * \brief Enter Sleep Mode.
 * Enter condition:  WFI + (SLEEPDEEP bit = 0) + (LPM bit = 0)
 */
void EnterSleepMode( void )
{
    PMC->PMC_FSMR &= (uint32_t)~PMC_FSMR_LPM ;
    SCB->SCR &= (uint32_t)~SCB_SCR_SLEEPDEEP_Msk ;

    __WFI() ;
}
/**
 * \brief Switch MCK to FastRC (Main On-Chip RC Oscillator).
 *
 * \param moscrcf Main On-Chip RC Oscillator Frequency Selection.
 * \param pres    Processor Clock Prescaler.
 */
void SwitchMck2FastRC(void)
{
    uint32_t timeout = 0;

    /* Switch to main clock */
    PMC->PMC_MCKR = (PMC->PMC_MCKR & (uint32_t)~PMC_MCKR_CSS_Msk) | PMC_MCKR_CSS_MAIN_CLK;
    for ( timeout = 0; !(PMC->PMC_SR & PMC_SR_MCKRDY) && (timeout++ < CLOCK_TIMEOUT) ; );

    PMC->PMC_MCKR = (PMC->PMC_MCKR & (uint32_t)~PMC_MCKR_PRES_Msk) | PMC_MCKR_PRES_CLK ;
    for ( timeout = 0; !(PMC->PMC_SR & PMC_SR_MCKRDY) && (timeout++ < CLOCK_TIMEOUT) ; );

    /* Switch Fast RC oscillator to 4Mhz .  */
    if( (PMC->CKGR_MOR & CKGR_MOR_MOSCRCF_Msk) != (0x0 << 4))
    {
        PMC->CKGR_MOR = (0x37 << 16) | CKGR_MOR_MOSCRCEN | (0x0<<4);
        /* Wait the Fast RC to stabilize */
        while ( !(PMC->PMC_SR & PMC_SR_MOSCRCS) ) ;
    }
    /* Disable PLLA */
    PMC->CKGR_PLLAR = (1 << 29);

    /* Disable PLLB */
    PMC->CKGR_PLLBR = (1 << 29);

    /* Set 0 FWS for Embedded Flash Access */
    EFC->EEFC_FMR = EEFC_FMR_FWS(0);
}

/**
 * \brief Switch MCK to FastRC (Main On-Chip RC Oscillator).
 *
 * \param moscrcf Main On-Chip RC Oscillator Frequency Selection.
 * \param pres    Processor Clock Prescaler.
 */
void SwitchMck2PLL(void)
{
    uint32_t timeout = 0;

    _Enable_PMC_Int();

    /* Enable Fast RC oscillator at 12Mhz .  */
    if( (PMC->CKGR_MOR & CKGR_MOR_MOSCRCF_Msk) != CKGR_MOR_MOSCRCF_12MHZ)
    {
        PMC->CKGR_MOR = (CKGR_MOR_KEY_VALUE | CKGR_MOR_MOSCRCEN | CKGR_MOR_MOSCRCF_12MHZ);
        /* Wait the Fast RC to stabilize */
        while ( !(PMC->PMC_SR & PMC_SR_MOSCRCS) ) ;
    }

    /* Initialize PLLA for image sensor */
    PMC->CKGR_PLLAR = BOARD_PLLAR;

    /* Initialize PLLB for MCK */
    PMC->CKGR_PLLBR = BOARD_PLLBR;

    /* enter sleep mode*/
    EnterSleepMode();

    while (!(PMC->PMC_SR & PMC_SR_LOCKB));
    while (!(PMC->PMC_SR & PMC_SR_LOCKA));


    /* Set FWS for Embedded Flash Access */
    EFC->EEFC_FMR = EEFC_FMR_FWS(NUMBER_WS);

    /* set pres */
    PMC->PMC_MCKR = BOARD_MCKR;

}

/**
 * \brief Performs the low-level initialization of the chip.
 * This includes EFC and master clock configuration.
 * It also enable a low level on the pin NRST triggers a user reset.
// */
void LowLevelInit( void )
{

}

