/*
 * barcode.h
 *
 * Created: 10/30/2012 9:34:59 AM
 *  Author: andy.gao
 */ 
#include "string.h"
#include "board.h"
#ifndef BARCODE_H_
#define BARCODE_H_
/********************************************************************/
/*                   Macro definitions		            */
/********************************************************************/
#define	JAN_BARS	61
#define IMAGE_WIDTH		320
#define IMAGE_HEIGHT		240
#define SCAN_LINES	     80
#define	Num_HIST	256


#define SRAM2_BASE (0x60200000)
#define CAP_DEST  (SRAM2_BASE)

int bin_gray_img_ohno(void);
int bin_gray_img_otsu(void);
int scan_bar_code(int dump);
void clear_numbers(void);
#endif /* BARCODE_H_ */