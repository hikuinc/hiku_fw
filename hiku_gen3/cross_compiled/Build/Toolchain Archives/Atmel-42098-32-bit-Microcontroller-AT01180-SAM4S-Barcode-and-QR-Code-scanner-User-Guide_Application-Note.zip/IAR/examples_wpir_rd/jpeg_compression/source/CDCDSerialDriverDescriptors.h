#ifndef _CDC_SERIAL_DESCRIPTORS_
#define _CDC_SERIAL_DESCRIPTORS_

/*----------------------------------------------------------------------------
 *      External variables
 *----------------------------------------------------------------------------*/

extern const USBDDriverDescriptors cdcdSerialDriverDescriptors ;

#endif // _CDC_SERIAL_DESCRIPTORS_
